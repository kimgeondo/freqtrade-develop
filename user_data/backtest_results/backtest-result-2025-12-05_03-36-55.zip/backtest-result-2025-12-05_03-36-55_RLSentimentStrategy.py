import logging
from functools import reduce
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
from freqtrade.strategy import IStrategy

class RLSentimentStrategy(IStrategy):
    
    minimal_roi = {"0": 0.1, "20": 0.05} 
    stoploss = -0.05
    timeframe = '5m'
    can_short = False 

    def feature_engineering_expand_all(self, dataframe: DataFrame, period, metadata: dict, **kwargs) -> DataFrame:
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["%mfi"] = ta.MFI(dataframe, timeperiod=14)
        bollinger = ta.BBANDS(dataframe, timeperiod=20)
        dataframe["%bb_width"] = (bollinger['upperband'] - bollinger['lowerband']) / bollinger['middleband']
        dataframe["%sentiment_score"] = self.get_mock_sentiment_score(dataframe)
        return dataframe

    def feature_engineering_expand_basic(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["%pct-change"] = dataframe["close"].pct_change()
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def feature_engineering_standard(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["%-raw_close"] = dataframe["close"]
        dataframe["%-raw_open"] = dataframe["open"]
        dataframe["%-raw_high"] = dataframe["high"]
        dataframe["%-raw_low"] = dataframe["low"]
        return dataframe

    def set_freqai_targets(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["&s_close"] = dataframe["close"].shift(-1) / dataframe["close"] - 1
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = self.freqai.start(dataframe, metadata, self)
        return dataframe

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        if "do_predict" in df.columns and "&-action" in df.columns:
            
            # [디버깅] AI가 보내는 신호가 무엇인지 눈으로 확인!
            # 이 로그가 터미널에 찍혀야 정상입니다.
            # 예: "AI ACTIONS: [3 4 5]" -> 이러면 매수하려고 난리 난 상태임
            actions = df['&-action'].unique()
            print(f">>> DEBUG: {metadata['pair']} AI ACTIONS: {actions}")

            # [핵심] 3, 4, 5번 행동을 매수(Long)로 인식
            enter_long_conditions = [
                df["do_predict"] == 1,
                (df["&-action"] >= 3) & (df["&-action"] <= 5)
            ]
            if enter_long_conditions:
                df.loc[
                    reduce(lambda x, y: x & y, enter_long_conditions),
                    ["enter_long", "enter_tag"]
                ] = (1, "long_entry")
        return df

    def populate_exit_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        if "do_predict" in df.columns and "&-action" in df.columns:
            # 6, 7, 8번 행동을 매도(Exit)로 인식
            exit_long_conditions = [
                df["do_predict"] == 1,
                (df["&-action"] >= 6) & (df["&-action"] <= 8)
            ]
            if exit_long_conditions:
                df.loc[
                    reduce(lambda x, y: x & y, exit_long_conditions),
                    "exit_long"
                ] = 1
        return df

    def get_mock_sentiment_score(self, dataframe):
        rsi_column = dataframe['%rsi']
        cond1 = (rsi_column > 70) 
        cond2 = (rsi_column < 30) 
        conditions = [cond1, cond2]
        choices = [0.8, -0.8]
        return np.select(conditions, choices, default=0.0)