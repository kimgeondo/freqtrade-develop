import logging
from functools import reduce
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
from freqtrade.strategy import IStrategy

class RLSentimentStrategy(IStrategy):
    
    # 기본 설정
    minimal_roi = {"0": 0.1, "20": 0.05} 
    stoploss = -0.05
    timeframe = '5m'
    can_short = False 

    # -------------------------------------------------------------------------
    # 1. Feature Engineering (State Space 구성)
    # -------------------------------------------------------------------------
    def feature_engineering_expand_all(self, dataframe: DataFrame, period, metadata: dict, **kwargs) -> DataFrame:
        # 기술적 지표
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["%mfi"] = ta.MFI(dataframe, timeperiod=14)
        bollinger = ta.BBANDS(dataframe, timeperiod=20)
        dataframe["%bb_width"] = (bollinger['upperband'] - bollinger['lowerband']) / bollinger['middleband']

        # 뉴스 감성 데이터
        dataframe["%sentiment_score"] = self.get_mock_sentiment_score(dataframe)
        return dataframe

    def feature_engineering_expand_basic(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["%pct-change"] = dataframe["close"].pct_change()
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def feature_engineering_standard(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        # 기존 표준 지표
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)

        # [중요] 강화학습 환경(Env)에서 사용할 가격 데이터 매핑
        # 이 부분이 없으면 AI가 현재 가격을 알 수 없어 에러가 발생합니다.
        dataframe["%-raw_close"] = dataframe["close"]
        dataframe["%-raw_open"] = dataframe["open"]
        dataframe["%-raw_high"] = dataframe["high"]
        dataframe["%-raw_low"] = dataframe["low"]
        
        return dataframe

    def set_freqai_targets(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["&s_close"] = dataframe["close"].shift(-1) / dataframe["close"] - 1
        return dataframe

    # -------------------------------------------------------------------------
    # 2. Strategy Logic (AI 행동 해석)
    # -------------------------------------------------------------------------
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = self.freqai.start(dataframe, metadata, self)
        return dataframe

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        if "do_predict" in df.columns and "&-action" in df.columns:
            # Action 1: 매수 (Long)
            enter_long_conditions = [
                df["do_predict"] == 1,
                (df["&-action"] == 1) 
            ]
            if enter_long_conditions:
                df.loc[
                    reduce(lambda x, y: x & y, enter_long_conditions),
                    ["enter_long", "enter_tag"]
                ] = (1, "long_entry")

        return df

    def populate_exit_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        if "do_predict" in df.columns and "&-action" in df.columns:
            # Action 2: 매도 (Exit)
            exit_long_conditions = [
                df["do_predict"] == 1,
                (df["&-action"] == 2)
            ]
            if exit_long_conditions:
                df.loc[
                    reduce(lambda x, y: x & y, exit_long_conditions),
                    "exit_long"
                ] = 1
        return df

    # --- 유틸리티 함수 ---
    def get_mock_sentiment_score(self, dataframe):
        rsi_column = dataframe['%rsi']
        
        cond1 = (rsi_column > 70) 
        cond2 = (rsi_column < 30) 
        
        conditions = [cond1, cond2]
        choices = [0.8, -0.8]
        
        return np.select(conditions, choices, default=0.0)