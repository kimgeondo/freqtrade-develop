import logging
from functools import reduce
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
from freqtrade.strategy import IStrategy

class RLSentimentStrategy(IStrategy):
    
    minimal_roi = {"0": 0.1, "20": 0.05} 
    stoploss = -0.05
    timeframe = '5m'
    can_short = False 

    def feature_engineering_expand_all(self, dataframe: DataFrame, period, metadata: dict, **kwargs) -> DataFrame:
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["%mfi"] = ta.MFI(dataframe, timeperiod=14)
        bollinger = ta.BBANDS(dataframe, timeperiod=20)
        dataframe["%bb_width"] = (bollinger['upperband'] - bollinger['lowerband']) / bollinger['middleband']
        dataframe["%sentiment_score"] = self.get_mock_sentiment_score(dataframe)
        return dataframe

    def feature_engineering_expand_basic(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["%pct-change"] = dataframe["close"].pct_change()
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def feature_engineering_standard(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["%-raw_close"] = dataframe["close"]
        dataframe["%-raw_open"] = dataframe["open"]
        dataframe["%-raw_high"] = dataframe["high"]
        dataframe["%-raw_low"] = dataframe["low"]
        return dataframe

    def set_freqai_targets(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["&s_close"] = dataframe["close"].shift(-1) / dataframe["close"] - 1
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = self.freqai.start(dataframe, metadata, self)
        return dataframe

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        if "do_predict" in df.columns and "&-action" in df.columns:
            # [수정됨] 9가지 행동 중 '매수'에 해당하는 행동은 3, 4, 5번입니다.
            # (3=매수+유지, 4=매수+좁힘, 5=매수+넓힘)
            enter_long_conditions = [
                df["do_predict"] == 1,
                (df["&-action"] >= 3) & (df["&-action"] <= 5)
            ]
            if enter_long_conditions:
                df.loc[
                    reduce(lambda x, y: x & y, enter_long_conditions),
                    ["enter_long", "enter_tag"]
                ] = (1, "long_entry")
        return df

    def populate_exit_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        if "do_predict" in df.columns and "&-action" in df.columns:
            # [수정됨] 9가지 행동 중 '매도'에 해당하는 행동은 6, 7, 8번입니다.
            exit_long_conditions = [
                df["do_predict"] == 1,
                (df["&-action"] >= 6) & (df["&-action"] <= 8)
            ]
            if exit_long_conditions:
                df.loc[
                    reduce(lambda x, y: x & y, exit_long_conditions),
                    "exit_long"
                ] = 1
        return df

    def get_mock_sentiment_score(self, dataframe):
        rsi_column = dataframe['%rsi']
        cond1 = (rsi_column > 70) 
        cond2 = (rsi_column < 30) 
        conditions = [cond1, cond2]
        choices = [0.8, -0.8]
        return np.select(conditions, choices, default=0.0)