import logging
from functools import reduce
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
from freqtrade.strategy import IStrategy

# Freqtrade 전용 로거 설정
logger = logging.getLogger(__name__)

class RLSentimentStrategy(IStrategy):
    
    minimal_roi = {"0": 0.1, "20": 0.05} 
    stoploss = -0.05
    timeframe = '5m'
    can_short = False 

    def feature_engineering_expand_all(self, dataframe: DataFrame, period, metadata: dict, **kwargs) -> DataFrame:
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["%mfi"] = ta.MFI(dataframe, timeperiod=14)
        bollinger = ta.BBANDS(dataframe, timeperiod=20)
        dataframe["%bb_width"] = (bollinger['upperband'] - bollinger['lowerband']) / bollinger['middleband']
        dataframe["%sentiment_score"] = self.get_mock_sentiment_score(dataframe)
        return dataframe

    def feature_engineering_expand_basic(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["%pct-change"] = dataframe["close"].pct_change()
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def feature_engineering_standard(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["%rsi"] = ta.RSI(dataframe, timeperiod=14)
        # 가격 데이터 매핑 (필수)
        dataframe["%-raw_close"] = dataframe["close"]
        dataframe["%-raw_open"] = dataframe["open"]
        dataframe["%-raw_high"] = dataframe["high"]
        dataframe["%-raw_low"] = dataframe["low"]
        return dataframe

    def set_freqai_targets(self, dataframe: DataFrame, **kwargs) -> DataFrame:
        dataframe["&s_close"] = dataframe["close"].shift(-1) / dataframe["close"] - 1
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # AI 예측 실행
        dataframe = self.freqai.start(dataframe, metadata, self)
        
        # [강력한 디버깅] AI가 예측값을 잘 넣어줬는지 확인
        if self.dp.runmode.value == 'backtest':
            # 데이터프레임 컬럼 중에 FreqAI 관련 컬럼이 있는지 검사
            freqai_cols = [c for c in dataframe.columns if "do_predict" in c or "&-action" in c]
            if not freqai_cols:
                logger.info(">>> [WARNING] AI 결과 컬럼이 없습니다! 학습이 제대로 안 된 것 같습니다.")
            else:
                # 실제 들어있는 값의 분포를 로그에 찍음
                unique_actions = dataframe['&-action'].unique() if '&-action' in dataframe.columns else "없음"
                logger.info(f">>> [SUCCESS] AI 행동 종류: {unique_actions}")
                
        return dataframe

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        # AI 결과가 있는지 확인
        if "do_predict" in df.columns and "&-action" in df.columns:
            
            # 매수 조건 (3, 4, 5번 행동)
            enter_long_conditions = [
                df["do_predict"] == 1,
                (df["&-action"] >= 3) & (df["&-action"] <= 5)
            ]
            
            if enter_long_conditions:
                df.loc[
                    reduce(lambda x, y: x & y, enter_long_conditions),
                    ["enter_long", "enter_tag"]
                ] = (1, "long_entry")
        
        return df

    def populate_exit_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        if "do_predict" in df.columns and "&-action" in df.columns:
            
            # 매도 조건 (6, 7, 8번 행동)
            exit_long_conditions = [
                df["do_predict"] == 1,
                (df["&-action"] >= 6) & (df["&-action"] <= 8)
            ]
            
            if exit_long_conditions:
                df.loc[
                    reduce(lambda x, y: x & y, exit_long_conditions),
                    "exit_long"
                ] = 1
        
        return df

    def get_mock_sentiment_score(self, dataframe):
        rsi_column = dataframe['%rsi']
        conditions = [(rsi_column > 70), (rsi_column < 30)]
        choices = [0.8, -0.8]
        return np.select(conditions, choices, default=0.0)